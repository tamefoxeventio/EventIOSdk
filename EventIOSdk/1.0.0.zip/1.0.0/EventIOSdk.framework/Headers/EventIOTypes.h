//
//  EventIOTypes.h
//  EventIO
//
//  Created by zena.tang on 2020/11/9.
//  Copyright © 2020 adjust GmbH. All rights reserved.
//

#ifndef EventIOTypes_h
#define EventIOTypes_h

typedef const void *EventIOConfigRef;



#endif /* EventIOTypes_h */
